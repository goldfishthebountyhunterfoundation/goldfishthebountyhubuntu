#!/bin/bash
#   @goldfishthebountyhunter   @goldfishthebountyhunter
#
#                        .++*++++++=-..                      
#                       .==-=--+--=+-=*.                     
#                  .-=+*******===--====:                     
#      ..:+***+..*+-============*#=-+==:.                    
#    .--.=++-.-*===============+===+*===+.                   
#   .*:*..=##*============++*##===+==+#=+*=.                 
#  .=-:.###++++========*:..    .+*=*==*+#==*.                
#  .+*##+========+===+.. .:****#+.*======**=                 
#  .+*#===+=========+.  .*-.:####*=*=====*+*.  .+**+.        
#   .#+===########==+   *+..=#####*-===+====*==+====*++-..   
#    =+===++++***===+  .*+.#######*-=====+==++#=++++*=---+-  
#    -+===+==+=+====+. .*+-*#####***==+==*=+++**=+=-===-===+.
#    .#=====+++======*  .#**###**+*===*++#**##+++====---=**-.
#     -+--============+=...====-+====+==+- .+===-==-====+-   
#     .++==-==============+++=========++#..+======-=--+=#.   
#      .=*==-====================++==++#:..++-==-=--*-:..    
#        :#+=================+=+++==*+#:. .++=-=-=--#..      
#         .+*+============+=======++*#.   .++=-=-=-==.       
#         .+=*#+++=========++*+++***...    =+=====*+.        
#         -+====*##+++++++===+*#*:.        -++*:...          
#         .*==+*.. ..:=++**+==+=.           :.               
#         .*=:...       ..+=+-=+=                            
#                         :+==++-                            
#                           .===.
#
#   @goldfishthebountyhunter   @goldfishthebountyhunter

chmod +x "/Users/$(whoami)/Desktop/goldfishthebountyhubuntu_app_v000004/goldfishthebountyhubuntu_app_v000004/yyynux/goldfishthebountyhunter_fivestarmenu_developmental.sh"
# bash -c "$HOME/Desktop/folder/script.sh" or bash -c "/home/$(whoami)/Desktop/folder/script.sh"
bash -c "/Users/$(whoami)/Desktop/goldfishthebountyhubuntu_app_v000004/goldfishthebountyhubuntu_app_v000004/yyynux/goldfishthebountyhunter_fivestarmenu_developmental.sh"

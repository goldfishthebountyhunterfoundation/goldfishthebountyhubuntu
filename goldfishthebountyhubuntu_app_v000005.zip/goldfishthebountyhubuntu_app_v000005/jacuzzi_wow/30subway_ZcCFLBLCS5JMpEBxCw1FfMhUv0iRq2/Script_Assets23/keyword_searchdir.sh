#!/bin/bash

#./searchdirectoryfor.sh bash

# This script will search for the keyword "bash" in all files within the specified directory (/path/to/directory), 
# and it will print the filenames where the keyword is found. You can modify the script to suit your specific requirements,
# such as searching for different keywords or specifying a different directory to search in.



# Check if the user provided a keyword
if [ -z "$1" ]; then
    echo "Usage: $0 <keyword>"
    exit 1
fi

# Directory to search
search_dir="/path/to/directory"

# Iterate over files in the directory
for file in "$search_dir"/*; do
    # Check if the file is a regular file
    if [ -f "$file" ]; then
        # Search for the keyword in the file
        if grep -q "$1" "$file"; then
            echo "Found in: $file"
        fi
    fi
done
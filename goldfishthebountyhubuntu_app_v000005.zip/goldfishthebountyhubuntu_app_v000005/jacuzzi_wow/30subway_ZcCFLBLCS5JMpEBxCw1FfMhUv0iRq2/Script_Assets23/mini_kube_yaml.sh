#!/bin/bash

minikube start
touch kustomization.yml
echo 
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  # Find the latest tag here: https://github.com/ansible/awx-operator/releases
  - github.com/ansible/awx-operator/config/default?ref=2.2.1

# Set the image tags to match the git version from above
images:
  - name: quay.io/ansible/awx-operator
    newTag: 2.2.1 

# Specify a custom namespace in which to install AWX
namespace: awx 

&gt; kustomization.yaml

kubectl apply -k .
kubectl config set-context --current --namespace=awx
echo
 ---
apiVersion: awx.ansible.com/v1beta1
kind: AWX
metadata:
  name: awx-demo
spec:
  service_type: nodeport
&gt; awx-demo.yml

echo 
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - github.com/ansible/awx-operator/config/default?ref=2.2.1
  - awx-demo.yaml
images:
  - name: quay.io/ansible/awx-operator
    newTag: 2.2.1

namespace: awx
&gt; kustomization.yaml
kubectl apply -k .
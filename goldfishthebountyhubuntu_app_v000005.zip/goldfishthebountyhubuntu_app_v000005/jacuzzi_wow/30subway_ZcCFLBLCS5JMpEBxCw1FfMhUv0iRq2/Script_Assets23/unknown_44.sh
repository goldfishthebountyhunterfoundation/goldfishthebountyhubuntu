#!/bin/bash


fail() {
	echo "$@"
	exit 1
}

echo "Export types"
echo "0 - type 0"
echo "1 - type 1"
echo "2 - type 2"
echo "Export type:"
read type
case $type in
	0) type="option0" ;;
	1) type="option1" ;;
	2) type="option2" ;;
	*) fail "Invalid type" ;;
esac

echo ""
echo "IDs"
echo "0 - id 0"
echo "1 - id 1"
echo "ID:"
read token
case $token in
	0) token="token0" ;;
	1) token="token1" ;;
	*) failure "Invalid token" ;;
esac

echo ""
echo "Channel ID:"
read id

token_arg=(
	--token "${token}"
)

if [ "${type}" = "option0" ]; then
		type_arg=( "" )
elif [ "${type}" = "option1" ]; then
		type_arg=( "" )
elif [ "${type}" = "option2" ]; then
		type_arg=( --guild )
else
		fail "Invalid type"
fi

"${HOME}/binary_to_run" \
		"${type}" \
		"${token_arg[@]}" \
		"${type_arg[@]}" \
		"${id}"

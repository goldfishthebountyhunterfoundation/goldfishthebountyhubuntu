#!/bin/bash

ulimit -n 4096
DB_USER="backups"
DB_PASS="random"
BASE_DIR="/home/$USER/backup/mysql"
YEAR=$(date +'%Y')
MONTH=$(date +'%B')
TIMESTAMP=$(date +'%H-%M_%d-%m-%Y')
YEAR_MONTH_DIR="$BASE_DIR/$YEAR/$MONTH/mysql_$TIMESTAMP"
mkdir -p "$YEAR_MONTH_DIR"
FULL="$YEAR_MONTH_DIR/full"
INCREMENTAL="$YEAR_MONTH_DIR/incremental"

# Delete old backup files
cd "$YEAR_MONTH_DIR" || exit 1
ls -t | tail -n +30 | xargs -I {} rm -- {}
echo "Deleted old files."

if [ $? -eq 0 ]; then
  delete_message="Old local MySQL dumps deleted successfully."
  echo "$delete_message"
  echo "$TIMESTAMP - $delete_message" >> /home/$USER/backup/mysql.log
else
  error_message="Error deleting local MySQL dumps."
  echo "$error_message"
  echo "$TIMESTAMP - $error_message" >> /home/$USER/backup/mysql.log
  exit 1
fi

# Full backup using innobackupex
innobackupex --user="$DB_USER" --password="$DB_PASS" --no-timestamp "$FULL"

if [ $? -eq 0 ]; then
  backup_message="Full backup with innobackupex completed successfully."
  echo "$backup_message"
  echo "$TIMESTAMP - $backup_message" >> "$FULL/log.txt"
else
  error_message="Error in innobackupex full backup."
  echo "$error_message"
  echo "$TIMESTAMP - $error_message" >> "$FULL/log.txt"
  exit 1
fi

# Incremental backup using innobackupex
last_full_backup=$(ls -1t "$FULL" | head -n 1)
innobackupex --user="$DB_USER" --password="$DB_PASS" --incremental "$INCREMENTAL" --incremental-basedir="$FULL/$last_full_backup"

if [ $? -eq 0 ]; then
  backup_message="Incremental backup with innobackupex completed successfully."
  echo "$backup_message"
  echo "$TIMESTAMP - $backup_message" >> "$INCREMENTAL/log.txt"
else
  error_message="Error in innobackupex incremental backup."
  echo "$error_message"
  echo "$TIMESTAMP - $error_message" >> "$INCREMENTAL/log.txt"
  exit 1
fi

# Compress individual full backup files into a tar.xz archive
tar -cJf "$FULL/${TIMESTAMP}_dumps.tar.xz" "$FULL"

if [ $? -eq 0 ]; then
  archive_message="MySQL full backups archived successfully."
  echo "$archive_message"
  echo "$TIMESTAMP - $archive_message" >> /home/$USER/backup/mysql.log
else
  error_message="Error archiving MySQL full backups."
  echo "$error_message"
  echo "$TIMESTAMP - $error_message" >> /home/$USER/backup/mysql.log
  exit 1
fi

# Compress individual incremental backup files into a tar.xz archive
tar -cJf "$INCREMENTAL/${TIMESTAMP}_incremental_dumps.tar.xz" "$INCREMENTAL"

if [ $? -eq 0 ]; then
  archive_message="MySQL incremental backups archived successfully."
  echo "$archive_message"
  echo "$TIMESTAMP - $archive_message" >> /home/$USER/backup/mysql.log
else
  error_message="Error archiving MySQL incremental backups."
  echo "$error_message"
  echo "$TIMESTAMP - $error_message" >> /home/$USER/backup/mysql.log
  exit 1
fi

# Bucket path
GCS_BUCKET="gs://fissara/backup/mysql"
GCS_PATH_FULL="$GCS_BUCKET/$YEAR/$MONTH/full/"
GCS_PATH_INCREMENTAL="$GCS_BUCKET/$YEAR/$MONTH/incremental/"

# Delete old backup files in the full bucket
gsutil ls "$GCS_PATH_FULL" | sort -r | tail -n +30 | xargs gsutil rm
echo "Deleted old full backup files in Google Cloud Storage."

if [ $? -eq 0 ]; then
  success_message="Old MySQL full backups deleted from Google Cloud Storage successfully."
  echo "$success_message"
  echo "$TIMESTAMP - $success_message" >> /home/$USER/backup/mysql.log
else
  error_message="Error deleting old MySQL full backups from Google Cloud Storage."
  echo "$error_message"
  echo "$TIMESTAMP - $error_message" >> /home/$USER/backup/mysql.log
  exit 1
fi

# Delete old backup files in the incremental bucket
gsutil ls "$GCS_PATH_INCREMENTAL" | sort -r | tail -n +30 | xargs gsutil rm
echo "Deleted old incremental backup files in Google Cloud Storage."

if [ $? -eq 0 ]; then
  success_message="Old MySQL incremental backups deleted from Google Cloud Storage successfully."
  echo "$success_message"
  echo "$TIMESTAMP - $success_message" >> /home/$USER/backup/mysql.log
else
  error_message="Error deleting old MySQL incremental backups from Google Cloud Storage."
  echo "$error_message"
  echo "$TIMESTAMP - $error_message" >> /home/$USER/backup/mysql.log
  exit 1
fi

# Copy the tar.xz archive of full backups to the full bucket
gsutil cp "$FULL/${TIMESTAMP}_dumps.tar.xz" "$GCS_PATH_FULL"

if [ $? -eq 0 ]; then
  success_message="MySQL full backups copied to Google Cloud Storage successfully."
  echo "$success_message"
  echo "$TIMESTAMP - $success_message" >> /home/$USER/backup/mysql.log
else
  error_message="Error copying MySQL full backups to Google Cloud Storage."
  echo "$error_message"
  echo "$TIMESTAMP - $error_message" >> /home/$USER/backup/mysql.log
  exit 1
fi

# Copy the tar.xz archive of incremental backups to the incremental bucket
gsutil cp "$INCREMENTAL/${TIMESTAMP}_incremental_dumps.tar.xz" "$GCS_PATH_INCREMENTAL"

if [ $? -eq 0 ]; then
  success_message="MySQL incremental backups copied to Google Cloud Storage successfully."
  echo "$success_message"
  echo "$TIMESTAMP - $success_message" >> /home/$USER/backup/mysql.log
else
  error_message="Error copying MySQL incremental backups to Google Cloud Storage."
  echo "$error_message"
  echo "$TIMESTAMP - $error_message" >> /home/$USER/backup/mysql.log
  exit 1
fi

exit 0
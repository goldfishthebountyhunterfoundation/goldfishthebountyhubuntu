     1  #!/bin/bash
     2  #H Join each line of 2 files ${1} & ${2} (may be ttt file IDs) [put ${3} at start ${4} in between and ${5} at the end]
     3  #h If $2 is not recognized as a fileName the $1 file will be used in its place
     4  #h If $3,$4,$5 includes 'CNT' a counter will replace the CNT in the output 
     5  #h The vars: fjoincnt3 fjoincnt4 fjoincnt5 may be set to the start value (default=1)
     6  #h The vars: fjoincnt3s fjoincnt4s fjoincnt5s may be set to the step string default='+1'
     7  #h Use: 'fjoin reset' to clear the vars
     8  
     9  [[ ! ${1} ]]&& return 1
    10  [[ ${1} == reset ]]&& unset -v fjoina fjoin2a fjoincnt fjoinsiz fjoincnt3 fjoincnt3s fjoincnt4 fjoincnt4s fjoincnt5 fjoincnt5s fjoinstr3 fjoinstr4 fjoinstr5 && return 0
    11  
    12  declare -a fjoina
    13  declare -a fjoin2a
    14  declare -i fjoincnt=0
    15  declare -i fjoinsiz=0
    16  declare fjoinstr3=''
    17  declare fjoinstr4=''
    18  declare fjoinstr5=''
    19  
    20  if [[ ! ${1} =~ / ]]&&[ -s "${RTMP}ttt${1}" ]; then # ttt file
    21    mapfile -t fjoina < "${RTMP}ttt${1}"
    22  elif [ -s "${1}" ]; then # normal file
    23    mapfile -t fjoina < "${1}"
    24  else
    25    echo "Error: no file found with: '${1}'" && return 1
    26  fi
    27  
    28  if [[ ! ${2} =~ / ]]&&[ -s "${RTMP}ttt${2}" ]; then # ttt file
    29    mapfile -t fjoin2a < "${RTMP}ttt${2}"
    30  elif [ -s "${2}" ]; then # normal file
    31    mapfile -t fjoin2a < "${2}"
    32  else
    33    if [[ ! ${1} =~ / ]]&&[ -s "${RTMP}ttt${1}" ]; then # ttt file
    34      mapfile -t fjoin2a < "${RTMP}ttt${1}"
    35    elif [ -s "${1}" ]; then # normal file
    36      mapfile -t fjoin2a < "${1}"
    37    fi
    38  fi
    39  
    40  if [[ ${3} =~ CNT ]]; then
    41    [[ ! ${fjoincnt3} ]]&& declare -i fjoincnt3=1
    42    [[ ! ${fjoincnt3s} ]]&& declare fjoincnt3s='+1'
    43  fi
    44  
    45  if [[ ${4} =~ CNT ]]; then
    46    [[ ! ${fjoincnt4} ]]&& declare -i fjoincnt4=1
    47    [[ ! ${fjoincnt4s} ]]&& declare fjoincnt4s='+1'
    48  fi
    49  
    50  if [[ ${5} =~ CNT ]]; then
    51    [[ ! ${fjoincnt5} ]]&& declare -i fjoincnt5=1
    52    [[ ! ${fjoincnt5s} ]]&& declare fjoincnt5s='+1'
    53  fi
    54  
    55  fjoinsiz=${#fjoina[*]}
    56  (( ${#fjoin2a[*]} > ${#fjoina[*]} ))&& fjoinsiz=${#fjoin2a[*]}
    57  
    58  while (( fjoincnt < fjoinsiz )); do
    59    fjoinstr3="${3}"
    60    [[ ${3} =~ CNT ]]&& fjoinstr3="${3//CNT/${fjoincnt3}}"
    61    fjoinstr4="${4}"
    62    [[ ${4} =~ CNT ]]&& fjoinstr4="${4//CNT/${fjoincnt4}}"
    63    fjoinstr5="${5}"
    64    [[ ${5} =~ CNT ]]&& fjoinstr5="${5//CNT/${fjoincnt5}}"
    65    printf %s\\n "${fjoinstr3}${fjoina[fjoincnt]}${fjoinstr4}${fjoin2a[fjoincnt]}${fjoinstr5}"
    66    [[ ${3} =~ CNT ]]&& fjoincnt3=$(( fjoincnt3 "${fjoincnt3s}" ))
    67    [[ ${4} =~ CNT ]]&& fjoincnt4=$(( fjoincnt4 "${fjoincnt4s}" ))
    68    [[ ${5} =~ CNT ]]&& fjoincnt5=$(( fjoincnt5 "${fjoincnt5s}" ))
    69    fjoincnt=$(( ++fjoincnt ))
    70  done
    71  unset -v fjoina fjoin2a fjoinstr3 fjoinstr4 fjoinstr5 fjoincnt fjoinsiz
    72  return 0

#!/bin/bash

# Function for Option 1
option1() {
    echo -e "\e[35mYou selected Option 1.\e[0m"
    echo -e "\e[35mYwpa_supplicant_wifi_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/wpa_supplicant_wifi_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 2
option2() {
    echo -e "\e[35mYou selected Option 2.\e[0m"
    echo -e "\e[35mwolfenstien_dosbox_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/wolfenstien_dosbox_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 4
option4() {
    echo -e "\e[35mYou selected Option 4.\e[0m"
    echo -e "\e[35mwindows_autoinstall_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/windows_autoinstall_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 5
option5() {
    echo -e "\e[35mYou selected Option 5.\e[0m"
    echo -e "\e[35mwebsite_domain_blocker_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/website_domain_blocker_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 6
option6() {
    echo -e "\e[35mYou selected Option 6.\e[0m"
    echo -e "\e[35mwebpage_network_scan_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/webpage_network_scan_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 7
option7() {
    echo -e "\e[35mYou selected Option 7.\e[0m"
    echo -e "\e[35mupdatetigervnc_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/updatetigervnc_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 8
option8() {
    echo -e "\e[35mYou selected Option 8.\e[0m"
    echo -e "\e[35mtime_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/time_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 9
option9() {
    echo -e "\e[35mYou selected Option 9.\e[0m"
    echo -e "\e[35msend_recieve_file_wormhole_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/send_recieve_file_wormhole_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 10
option10() {
    echo -e "\e[35mYou selected Option 10.\e[0m"
    echo -e "\e[35msatori_network_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/satori_network_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 11
option11() {
    echo -e "\e[35mYou selected Option 11.\e[0m"
    echo -e "\e[35mrun_thousandsofcurlbackgroundprocesses_inparallel_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/run_thousandsofcurlbackgroundprocesses_inparallel_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 12
option12() {
    echo -e "\e[35mYou selected Option 12.\e[0m"
    echo -e "\e[35mrandom_shutdown_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/random_shutdown_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 13
option13() {
    echo -e "\e[35mYou selected Option 13.\e[0m"
    echo -e "\e[35mqemu_setup_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/qemu_setup_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 14
option14() {
    echo -e "\e[35mYou selected Option 14.\e[0m"
    echo -e "\e[35mprocess_blocking_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/process_blocking_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 15
option15() {
    echo -e "\e[35mYou selected Option 15.\e[0m"
    echo -e "\e[35mnodejs_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/nodejs_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 16
option16() {
    echo -e "\e[35mYou selected Option 16.\e[0m"
    echo -e "\e[35mmake_dirs_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/make_dirs_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 17
option17() {
    echo -e "\e[35mYou selected Option 17.\e[0m"
    echo -e "\e[35minstall_java_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/install_java_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 18
option18() {
    echo -e "\e[35mYou selected Option 18.\e[0m"
    echo -e "\e[35mhikvision_ipcam_exploit_sh.txt\e[0m"
    FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/hikvision_ipcam_exploit_sh.txt"
    cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 19
option19() {
    echo -e "\e[35mYou selected Option 19.\e[0m"
    echo -e "\e[35mYou selected Option 19.\e[0m"
    # FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/somefile.txt"
    # cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 20
option20() {
    echo -e "\e[35mYou selected Option 20.\e[0m"
    echo -e "\e[35mYou selected Option 20.\e[0m"
    # FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/somefile.txt"
    # cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 21
option21() {
    echo -e "\e[35mYou selected Option 21.\e[0m"
    echo -e "\e[35mYou selected Option 21.\e[0m"
    # FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/somefile.txt"
    # cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 22
option22() {
    echo -e "\e[35mYou selected Option 22.\e[0m"
    echo -e "\e[35mYou selected Option 22.\e[0m"
    # FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/somefile.txt"
    # cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 23
option23() {
    echo -e "\e[35mYou selected Option 23.\e[0m"
    echo -e "\e[35mYou selected Option 23.\e[0m"
    # FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/somefile.txt"
    # cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 24
option24() {
    echo -e "\e[35mYou selected Option 24.\e[0m"
    echo -e "\e[35mYou selected Option 24.\e[0m"
    # FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/somefile.txt"
    # cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 25
option25() {
    echo -e "\e[35mYou selected Option 25.\e[0m"
    echo -e "\e[35mYou selected Option 25.\e[0m"
    # FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/somefile.txt"
    # cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}
# Function for Option 26
option26() {
    echo -e "\e[35mYou selected Option 26.\e[0m"
    echo -e "\e[35mYou selected Option 26.\e[0m"
    # FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/somefile.txt"
    # cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 27
option27() {
    echo -e "\e[35mYou selected Option 27.\e[0m"
    echo -e "\e[35mYou selected Option 27.\e[0m"
    # FILE="$HOME//Desktop/jacuzzi/jacuzzi_wow/30subway_ZcCFLBLCS5JMpEBxCw1FfMhUv0iRq2/Script_Assets22/somefile.txt"
    # cat "$FILE"
    # Add your commands
    read -p "Press enter to return to the main menu..."
}

# Function for Option 3
option3() {
    while true; do
        clear
        echo -e "\e[35m=======================\e[0m"
        echo -e "\e[35m       SUBMENU       \e[0m"
        echo -e "\e[35m=======================\e[0m"
        echo -e "\e[35m1. Sub Option 1\e[0m"
        echo -e "\e[35m2. Sub Option 2\e[0m"
        echo -e "\e[35m3. Return to Main Menu\e[0m"
        echo -e "\e[35m4. Exit\e[0m"
        echo -e "\e[35mn "Please choose a sub-option:" \e[0m"
        read sub_choice

        case $sub_choice in
            1)
                echo -e "\e[35mYou selected Sub Option 1.\e[0m"
                # Add your command for Sub Option 1 here
                read -p "Press enter to continue..."
                ;;
            2)
                echo -e "\e[35mYou selected Sub Option 2.\e[0m"
                # Add your command for Sub Option 2 here
                read -p "Press enter to continue..."
                ;;
            3)
                break
                ;;
            4)
                echo -e "\e[35mExiting...\e[0m"
                exit 0
                ;;
            *)
                echo -e "\e[35mInvalid option, please try again.\e[0m"
                read -p "Press enter to continue..."
                ;;
        esac
    done
}

# Main Menu Loop
while true; do
    clear
    echo -e "\e[35m───▐▀▄───────▄▀▌───▄▄▄▄▄▄▄\e[0m"
    echo -e "\e[35m───▌▒▒▀▄▄▄▄▄▀▒▒▐▄▀▀▒██▒██▒▀▀▄\e[0m"
    echo -e "\e[35m──▐▒▒▒▒▀▒▀▒▀▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▀▄\e[0m"
    echo -e "\e[35m──▌▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▄▒▒▒▒▒▒▒▒▒▒▒▒▀▄\e[0m"
    echo -e "\e[35m▀█▒▒▒█▌▒▒█▒▒▐█▒▒▒▀▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▌\e[0m"
    echo -e "\e[35m▀▌▒▒▒▒▒▒▀▒▀▒▒▒▒▒▒▀▀▒▒▒▒▒▒▒▒▒▒▒▒▒▒▐───▄▄\e[0m"
    echo -e "\e[35m▐▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▌▄█▒█\e[0m"
    echo -e "\e[35m▐▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒█▀\e[0m"
    echo -e "\e[35m▐▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▀\e[0m"
    echo -e "\e[35m░█▀▀░▀█▀░█▀▀░█▀█░░█▀▀░▀█▀░█▀▀░█▀█░\e[0m"
    echo -e "\e[35m░▀▀█░░█░░█▀▀░█▀▀░░▀▀█░░█░░█▀▀░█▀▀░\e[0m"
    echo -e "\e[35m░▀▀▀░░▀░░▀▀▀░▀░░░░▀▀▀░░▀░░▀▀▀░▀░░░\e[0m"
    echo -e "\e[35m.\e[0m"
    #echo -e "\e[35m🟩🟩🟩🈯🗻🟧🈯🗻🟧🟩🟩🟩🟩🟩\e[0m"
    #echo -e "\e[35m🟩🟩🈯🈯🗻🟧🈯🗻🟧🟩🟩🟩🟩🟩\e[0m"
    #echo -e "\e[35m🈯🈯🈯🈯🗻🟧🈯🗻🟧🟩🟩🟩🟩🟩\e[0m"
    #echo -e "\e[35m🟫🈯🈯🈯🗻🗻🗻🗻🗻🈯🈯🈯🟩🟩\e[0m"
    #echo -e "\e[35m🈯🈯🈯🈯🗻🗻🗻🗻🗻🗻🈯🈯🈯🈯\e[0m"
    #echo -e "\e[35m🈯🈯🈯🈯🗻🗻⚪🗻⚪🗻🈯🈯🈯🈯\e[0m"
    #echo -e "\e[35m🈯🈯🈯🈯⬜⬜⬜⬜⬜⬜🈯🈯🈯🈯\e[0m"
    #echo -e "\e[35m🈯🈯🈯🈯🗻⬜🟥⚪⬜⬜🈯🈯🈯🈯\e[0m"
    #echo -e "\e[35m🈯🈯🈯🗻🗻⬜⬜🟥⬜🗻🗻🈯🈯🈯\e[0m"
    #echo -e "\e[35m🈯🈯🗻🗻🗻⬜⬜⬜⬜⬜🗻🗻🗻🈯\e[0m"
    #echo -e "\e[35m🗻🗻🗻🗻⬜⬜⬜⬜⬜⬜⬜🗻🗻🗻\e[0m"
    #echo -e "\e[35m🗻🗻🗻⬜⬜⬜⬜⬜⬜⬜⬜⬜🗻🗻\e[0m"
    #echo -e "\e[35m⚪🗻🗻⬜⬜⬜⬜⬜⬜⬜⬜⬜⚪⚪\e[0m"
    #echo -e "\e[35m⚪🗻⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⚪\e[0m"
    #echo -e "\e[35m🗻🗻⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜🈯\e[0m"
    #echo -e "\e[35m🗻🗻🗻⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜🈯\e[0m"
    #echo -e "\e[35m🈯🗻🗻⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜🈯\e[0m"




    # ____________
# <>  HelloWorld <>
    # ------------
    #    \   ^__^
    #     \  (oo)\_______
    #        (__)\       )\/\
    #            ||----w |
    #            ||     ||

    echo -e "\e[35m=======================\e[0m"
    echo -e "\e[35m   STEPSTEP CLIENT\e[0m"
    echo -e "\e[35m=======================\e[0m"
    echo -e "\e[35m.\e[0m"
    echo -e "\e[35m1. wpa_supplicant_wifi_sh.txt // 2. wolfenstien_dosbox_sh.txt // 4. windows_autoinstall_sh.txt\e[0m"
    echo -e "\e[35m5. website_domain_blocker_sh.txt // 6. webpage_network_scan_sh.txt // 7. updatetigervnc_sh.txt\e[0m"
    echo -e "\e[35m8. time_sh.txt // 9. send_recieve_file_wormhole_sh.txt // 10. satori_network_sh.txt\e[0m"
    echo -e "\e[35m11. run_thousandsofcurlbackgroundprocesses_inparallel_sh.txt// 12. random_shutdown_sh.txt // 13. qemu_setup_sh.txt\e[0m"
    echo -e "\e[35m14. process_blocking_sh.txt // 15. nodejs_sh.txt // 16. make_dirs_sh.txt\e[0m"
    echo -e "\e[35m17. install_java_sh.txt // 18. hikvision_ipcam_exploit_sh.txt // 19. Option 19\e[0m"
    echo -e "\e[35m20. Option 20 // 21. Option 21 // 22. Option 22\e[0m"
    echo -e "\e[35m23. Option 23 // 24. Option 24 // 25. Option 25\e[0m"
    echo -e "\e[35m26. Option 26 // 27. Option 27 // 28. Option 28\e[0m"
    echo -e "\e[35m333. Exit\e[0m"
    echo -e "\e[35mn "Please choose an option:" \e[0m"
    read choice

    case $choice in
        1)
            option1
            ;;
        2)
            option2
            ;;
        3)
            option3
            ;;
        4)
            option4
            ;;
        5)
            option5
            ;;
        6)
            option6
            ;;
        7)
            option7
            ;;
        8)
            option8
            ;;
        9)
            option9
            ;;
        10)
            option10
            ;;
        11)
            option11
            ;;
        12)
            option12
            ;;
        13)
            option13
            ;;
        14)
            option14
            ;;
        15)
            option15
            ;;
        16)
            option16
            ;;
        17)
            option17
            ;;
        18)
            option18
            ;;
        19)
            option19
            ;;
        20)
            option20
            ;;
        21)
            option21
            ;;
        22)
            option22
            ;;
        23)
            option23
            ;;
        24)
            option24
            ;;
        25)
            option25
            ;;
        26)
            option26
            ;;
        27)
            option27
            ;;
        333)
            echo -e "\e[35mExiting...\e[0m"
            exit 0
            ;;
        *)
            echo -e "\e[35mInvalid option, please try again.\e[0m"
            read -p "Press enter to continue..."
            ;;
    esac
done

#ᒪOᒪᒪYᑭOᑭ ᒍEᔕᑌᔕ (ᔕᑌᑕKEᖇᔕ)

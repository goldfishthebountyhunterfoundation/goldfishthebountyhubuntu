#!/bin/bash
#!/bin/ksh

commands=(


    "echo \"---- Minecraft Crash Report ----\""
    "echo \"// Hey, that tickles! Hehehe!\""
    "echo \"  _    _          _   _      ____   ____   _____ ______ _____   _____ _\""
    "echo \" | |  | |   /\   | | | |    / __ \ / __ \ / ____|  ____|  __ \ / ____| |\""
    "echo \" | |__| |  /  \  | | | |   | |  | | |  | | (___ | |__  | |__) | (___ | |\""
    "echo \" |  __  | / /\ \ | | | |   | |  | | |  | |\___ \|  __| |  _  / \___ \| |\""
    "echo \" | |  | |/ ____ \|_| | |___| |__| | |__| |____) | |____| | \ \ ____) |_|\""
    "bash -c 'echo \" |_|  |_/_/    \_(_) |______\____/ \____/|_____/|______|_|  \_\_____/(_)\"'"
    "sleep 2"
    "clear"
    "whoami && hostname -I"
    "ls -l /proc/$$/exe"
    "fdisk -l /dev/sda"
    "sleep 5"

    # Update kERNEL
    #"sudo apt dist-upgrade"

    # Download the image [LEGACY LINK NEEDED]

    # Clone ISO DOwnload [AMD64 or EM64T architecture (e.g., Athlon64, Opteron, EM64T Xeon, Core 2]
    # 071d5a534c1a2d61d64c6599c47c992c778e08b054daecc2540d57929e4ab1fd *ubuntu-22.04.4-desktop-amd64.iso
    "curl -O http://releases.ubuntu.com/22.04/ubuntu-22.04.4-desktop-amd64.iso"


    # Clone Android-X86 ISO DOwnload [Android 9.0.0 Pie release (android-9.0.0_r54)]
    # sha1sum: 1cc85b5ed7c830ff71aecf8405c7281a9c995aa0
    "curl -O https://osdn.net/dl/android-x86/android-x86-9.0-r2.iso"
    #hxxps://osdn[dot]net/projects/android-x86/downloads/71931/android-x86-9.0-r2.iso/

    
    # Clone ISO DOwnload ( ARCHIVE )
    "curl -JOL hxxps://archive.org/download/goldfishthebountyhubuntu-22.04.4-AMD64/goldfishthebountyhubuntu-22.04.4-AMD64.iso"
    # Internet Archive Download Batch Files
    #hxxps://blog.archive[dot]org/2012/04/26/downloading-in-bulk-using-wget/#:~:text=Here%E2%80%99s%20an%20overview%20of%20what%20we%E2%80%99ll%20do%3A%201,those%20identifiers%204%204.%20Run%20the%20wget%20command.
    # Must pull downloads from itemslist.txt (start w .csv extension then change file to .txt)

    # Get all files from ID_list.txt
    # $wget -r -H -nc -np -nH --cut-dirs=1 -e robots=off -l1 -i ./itemlist.txt -B 'http://archive.org/download/'
    # Adds Filter for accepted file extensions (A)
    # $wget -r -H -nc -np -nH --cut-dirs=1 -A .pdf,.epub -e robots=off -l1 -i ./itemlist.txt -B 'http://archive.org/download/'
    # Adds Filter for rejected file extensions (R)
    # $wget -r -H -nc -np -nH --cut-dirs=1 -R .tar,.zip -e robots=off -l1 -i ./itemlist.txt -B 'http://archive.org/download/'
    # Ubuntu
    # $wget -r -l 1 -nc -H -np -nH -e robots=off  --cut-dirs=3 -i ../itemlist.txt -B ‘http://www.archive.org/download/’

    # Write the image to a USB flash drive
    #"lsblk"
    #"sudo umount /dev/sdx?"
    #"sudo dd bs=4M conv=fsync status=progress \ if=goldfishthebountyhubuntu-22.04.4-AMD64.iso of=/dev/sdx"


    #RANDO COMMANDS
 
    # Nicer Column LS Command
    # $ printf "|%20s|%20s|%20s|%20s|\n" $(ls) : %20s

    # LSCPI
    # $ lspci -nnk | grep -EiA3 net

    # LSMOD
    # $ lsmod | grep -i wl

    # SYSTEMD
    # $ journalctl -b -g broadcom

    # CHANGE GEO
    # $ timedatectl set-timezone America/Chicago

    # Concat files together with a header path
    # $ tail -n +1 $(find . -type f)

    # DISPLAY
    # $ sudo tac /var/log/syslog | grep cron | less


    # UNREVERSE TEXT
    # $ echo "ved.kcardlop.ztirom.tcatnoc" | sed s/\\./@/3 | rev

    # curl base64 string
    # $ curl $(echo 'base64stringhere' | base64 -d)
   
    # Check command exec type (echo = ELF)
    # $ od -bc /bin/echo | head -4

    # Find Command ( /home locate files larger than 10,000 bytes)
    # $ sudo find /home -size +10000

    # Find Command ( gives even more info)
    # $ sudo find /home -size +10000 -ls 

    # Find files with perticular permissions
    # $ sudo find /home/nemo -perm /u=w.g=w

    # Find empty files 
    # $ find . -empty -type f -ls

    # count how many files have been accessed in the last hour
    # $ sudo find /home -amin -60 | wc -l

    # find files that dont belong to me <-----------------------------
    # $ find . ! -user $USER -ls

    # find files that dont belong to me and remove prompt
    # $ find . ! -user $USER -ok rm {} \;

    # find files w no user
    # $ find . -nouser $USER -ls

    # find files w no user
    # $ find . -nouser $USER -ls

    # API to Get Public IP
    # $ curl -4 icanhazip.com

    # OS Type
    # $ lsb_release -d
    # $ lsb_release -a

    #Nvidia drivers ubuntu

    #libxnvctrl0
    #libnvidia-cfg1-515
    #libnvidia-common-515
    #libnvidia-compute-515
    #libnvidia-egl-wayland1
    #nvidia-compute-utils-515
    #nvidia-cuda-toolkit
    #nvidia-dkms-515
    #nvidia-kernel-common-515
    #nvidia-kernel-source-515
    #nvidia-prime
    #nvidia-settings
    #xserver-xorg-video-nvidia-515

    # iNSTALLER
    "echo \"The /etc/apt/sources.list file
   contains a list of locations from which to retrieve desired package
   files.""
    sleep 9

    #///# NON-STACK-SOFTWARE #///#
    # Install wget
    "sudo apt install -y Tixati" x
    # Install wget
    "sudo apt install -y ncdu"
    # Install wget
    "sudo apt install -y tilix"
    # Install wget
    "sudo apt install -y lollipop"
    # Phone Mirroring
    "sudo apt install -y Scrpy" x
    # Desktop Show IP
    "sudo apt install -y indicator-ip"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"

    #///# FLATPAK-SOFTWARE #///#

    # Win on LIN
    "sudo flatpak install -y bottles"
    # Brave Broswer
    "sudo flatpak install -y brave"
    # Boxes VM
    "sudo flatpak install -y boxes"
    # tor file share
    "sudo flatpak install -y Onionshare"


    #///# STACK-SOFTWARE #///#
    
    # is a free and open-source message broker.
    #"sudo apt install -y RabbitMQ"
    # is an open standard for decentralized and end-to-end encrypted communication.
    #"sudo apt install -y Matrix"
    # is a free, open-source, and feature-rich FTP server written for Unix and Unix-a-like operating systems
    #"sudo apt install -y ProFTPD"
    # is a free (BSD-license)
    #"sudo apt install -y Pure-FTPd"
    # is an open-source task management software written in Ruby
    #"sudo apt install -y OpenProject"
    # is a free, open-source, large-scale indexed packet capture and search tool
    #"sudo apt install -y Arkime"
    #is a free, open-source, NoSQL database management system designed to handle large amounts of data.
    #"sudo apt install -y Cassandra"
    # is an open-source monitoring tool that can be used to monitor servers
    #"sudo apt install -y Monit"
    # is a free, open-source system and powerful network monitoring tool for Linux
    #"sudo apt install -y Munin"
    # is a free, open-source, and multi-cluster orchestration platform that allows organizations to deploy containers in a production environment. 
    #"sudo apt install -y Rancher"
    # is a free, open-source, and lightweight server implementation of the MQTT protocol
    #"sudo apt install -y Mosquitto"
    # is an open-source, self-hosted file synchronization and sharing platform.
    #"sudo apt install -y Seafile"
    # is an open-source implementation of the .NET framework and compatible software framework for building cross-platform applications.
    #"sudo apt install -y Mono"
    # is a free and open-source server management console that makes it easy to administer your Linux servers via a web browser.
    #"sudo apt install -y Cockpit"
    # is an open-source infrastructure automation tool that allows you to deploy and manage hundreds of servers via a command-line interface.
    #"sudo apt install -y Terraform"
    # an open-source and agent-less vulnerability scanner - on an Ubuntu 22.04 server.
    #"sudo apt install -y Vuls"
    # Cells also known as a Pydio is an open-source file-sharing and synchronization application written in the Golang language.
    #"sudo apt install -y Pydio"
    # is an open-source network vulnerability scanner for vulnerability assessments and penetration testing.
    #"sudo apt install -y Nessus"
    # is free and open-source VPN software that can be used to create mesh VPN networks
    #"sudo apt install -y Tinc"
    # is a free, open-source, and worlds leading security monitoring tool used as a network intrusion detection system 
    #"sudo apt install -y Zeek"
    # is an open-source tool for managing containers, images, volumes, and pods (group of containers).
    #"sudo apt install -y Podman"
    # is a free and open-source log monitoring tool used for capturing, storing, and enabling real-time analysis of terabytes of machine data.
    #"sudo apt install -y Graylog"
    # is a free, open-source, and console-based network traffic monitoring tool for Linux operating system.and network traffic analyzer.
    #"sudo apt install -y vnStat"
    # is free and open-source DNS server software that can be used for validating, recursive, and caching DNS resolvers.
    #"sudo apt install -y Unbound"
    # is an open-source network monitoring and graphing tool written in PHP.
    #"sudo apt install -y Cacti"
    # is an open-source tool used to track and graph the performance of computer systems.
    #"sudo apt install -y Graphite"
    # is a free and open-source image hosting and sharing software that allows you to host your own image hosting server on the web.
    #"sudo apt install -y Chevereto"
    # is an open-source and web-based file-sharing application for Linux based operating system.
    #"sudo apt install -y FileRun"
    # or Very Secure FTP Daemon is free and open-source FTP Server software.
    #"sudo apt install -y vSFTPd"
    # is a free and open-source chat, telephony, and video conferencing tool
    #"sudo apt install -y Jitsi"
    # is a simple, lightweight, and high-performance HTTP server and can handle hundreds of thousands of concurrent connections.
    #"sudo apt install -y OpenLiteSpeed"
    # is a free, open source, fully featured and highly configurable SFTP server with optional HTTP/S, FTP/S and WebDAV support.
    #"sudo apt install -y SFTPGo"
    # is a free and open-source server used for deploying Java-based applications.
    #"sudo apt install -y Glassfish"
    # is an open-source office suite distributed under GNU AGPL v3.0. 
    #"sudo apt install -y ONLYOFFICE"

    #///# USER-SOFTWARE #///#

    # File Management
    # File finder
    #"sudo apt install -y Ulauncher"
    # Duplicate file finder
    #"sudo apt install -y FSlint"
    # File cleaning
    #"sudo apt install -y Flatsweep"
    # Metadata
    #"sudo apt install -y Metadata Cleaner"

    # System Optimization
    # System Optimization and Monitoring
    #"sudo apt install -y Stacer"
    # Laptop battery optimization
    #"sudo apt install -y TLP"
    # Application startup optimization
    #"sudo apt install -y Preload"

    # Keeping your stuff safe
    # Password management
    #"sudo apt install -y Bitwarden"
    # Backup system data
    #"sudo apt install -y Timeshift"
    # Backup personal data
    #"sudo apt install -y luckyBackup && sudo apt install -y Pika Backup"
    
    # Internet and communication
    # Internet browsing
    #"sudo apt install -y Firefox"
    # Email
    #"sudo apt install -y BlueMail && sudo apt install -y Thunderbird"
    # RSS Feeds
    #"sudo apt install -y Inoreader"
    # Mobile integration / android interfacing
    #"sudo apt install -y Zorin Connect && sudo apt install -y kdeconnect"

    # Productivity
    # Office functionality
    #"sudo apt install -y ONLYOFFICE"
    # To Do
    #"sudo apt install -y Zenkit To Do"
    # Task management
    #"sudo apt install -y Zenkit Base"
    # Project management
    #"sudo apt install -y Zenkt Projects"


    # Note taking
    #"sudo apt install -y Joplin"
    # Text Editing
    #"sudo apt install -y Frog"
    # Reference
    #"sudo apt install -y Zotero"
    # Mind mapping
    #"sudo apt install -y Minder"
    # Take breaks
    #"sudo apt install -y GoForIt!"

    # Creativity
    # Color Management
    #"sudo apt install -y DisplayCAL"
    # Photo and video import
    #"sudo apt install -y Rapid Photo Downloader"
    # Photo management
    #"sudo apt install -y digiKam"
    # Photo RAW editing
    #"sudo apt install -y darktable"
    # Traditional film processing but digital
    #"sudo apt install -y Filmulator"
    # Image manipulation
    #"sudo apt install -y GIMP"
    # Video editing
    #"sudo apt install -y DaVinci Resolve"
    # Video Conversion
    #"sudo apt install -y WinFF"
    # Desktop publishing
    #"sudo apt install -y Scribus"
    # Vector drawing
    #"sudo apt install -y Inkscape"
    # Artistic drawing
    #"sudo apt install -y Krita"
    # Image upscaling
    #"sudo apt install -y Upscayl"

    # Tools
    # Reduce eye strain
    #"sudo apt install -y SafeEyes"
    # Screenshots
    #"sudo apt install -y Shutter"
    # PDF Reader
    #"sudo apt install -y Evince"
    # PDF Editor
    #"sudo apt install -y LibreOffice Draw"
    # Music management
    #"sudo apt install -y Strawberry"
    # Home administration
    #"sudo apt install -y Homebank"
    # Web Reading
    #"sudo apt install -y Pocket"
    # Permissions
    #"sudo apt install -y Flatseal"
    # Keep-awake
    #"sudo apt install -y Caffeine"
    # Cron Job 
    #"sudo apt install -y cronie"
    #"crond -v"
    #"systemctl enable crond"



    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
    # Install wget
    "sudo apt install -y wget"
)

execute_command() {
    local command="$1"
    local command_name="$2"
    
    echo "Executing $command_name..."
    eval "$command"
    
    if [ $? -eq 0 ]; then
        echo "$command_name completed successfully."
    else
        echo "Error: $command_name failed to execute."
        exit 1  # Exit the script with an error code
    fi
}

# Loop through the commands
for ((i=0; i<${#commands[@]}; i++)); do
    execute_command "${commands[$i]}" "Command $((i+1))"
done

reboot




# List Avaible Linux Shells
$ cut -d ':' -f 7 /etc/passwd | sort -u 

# List Currently Using Shell ## askubuntu[dot]com
$ echo shell
$ cat /proc/$$/comm
$ ps -p $$ -o args

# What Process Am I Running Right Now?
$ ls -l /proc/$$/exe


#$ bash -c /path/to/some_config.sh


#$ sudo apt install ./opera-stable_105.0.4970.16_amd64.deb








#$ reboot" # [EXIT]




# packages=()

# $ apt install "${packages[@]}"


# NEW SOFTWARE INSTALLER

# NEW CURL?
#$ sudo apt install -y aria2         ## Download Client ## 
# PURPOSE
#$ sudo apt install -y uget          ## Download Client ##
# PURPOSE
#$ snap install midori.              ## Browser ## worked
# PURPOSE
#$ sudo apt install -y lightdm.      ## Light Desktop Manager worked 
# Emulator's
#$ sudo apt install -y Sakura        ## Terminal Emu ### x
# PURPOSE
#$ sudo apt install -y Byobu.        ## Window Multi-Plexer ### x

# apachefriends[dot]org/download.html
# vitux[dot]com/ubuntu-xampp/
#$ sudo apt install -y xampp

# community.apachefriends[dot]org/f/viewtopic.php?p=130646
#$ sudo apt install -y net-snmp

# PURPOSE
#$ sudo apt install -y virt-manager <---

# PURPOSE
#$ sudo apt install -y rsync

# PURPOSE
#$ sudo apt install -y docker

# PURPOSE
#$ sudo apt install -y timeshift     

# PURPOSE
#$ sudo apt install -y mission-center ## System Vitals ##

# PURPOSE
#$ sudo apt install git
#$ sudo apt install -y zsh && sudo apt install -y fish  ## worked
#$ sh -c "$(wget https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh -O -)"
#$ sudo gedit ~/.zshrc ##  Append -> ZSH_THEME=( "gnzh" )
# Live Wallpaper
#$ sudo apt install -y Komorebi

# PURPOSE
#$ sudo apt install -y woeusb

# PURPOSE
#$ sudo apt install -y

# PURPOSE
#$ sudo apt install -y

# PURPOSE
#$ sudo apt install -y

# PURPOSE
#$ sudo apt install -y

# PURPOSE
#$ sudo apt install -y

# PURPOSE
#$ sudo apt install -y

# PURPOSE
#$ sudo apt install -y



# gsettings set org.gnome.desktop.background picture-uri "file:///path/to/your/image.jpg"


# hxxps://polyformproject.org/licenses/strict/1.0.0


#/# OTHER STUFF #/#


# Install QEMU
# $ sudo pacman -S qemu-system-x86        # On Arch/Endavour
# $ sudo apt-get install qemu-system-x86  # On Debian/Ubuntu

# BOOT iso in qemu from shell
# $ qemu-system-x86_64 \
#   -enable-kvm \
#   -m 2G \
#   -drive file=lightwhale-2.1.4-x86.iso,format=raw,if=virtio \
#   -device virtio-rng-pci \
#   -net nic,model=virtio \
#   -net user,hostfwd=tcp::10022-:22,hostfwd=tcp::10080-:80


# $ sudo apt install flatpak
# $ flatpak --user remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo

# Local Backup
# $ rsync -av /source/directory/ /destination/directory/

# Remote Backup (using SSH)
# $ rsync -av -e ssh /source/directory/ user@remote_host:/destination/directory/


#/# OTHER STUFF 2 #/#

# Expand to source files
# $ ls -la ~/ | more


# Set up Docker's apt repository.

# Add Docker's official GPG key:
sudo apt-get update
sudo apt-get install ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Add the repository to Apt sources:
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  
sudo apt-get update

# Install Docker
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Verify that the Docker Engine installation is successful
 sudo docker run hello-world